// src/modules/ReportForm/api/reportForm.ts
export interface RevenueConfig {
    propertyIds: string[];
    range: { start: string; end: string };
    groupBy: 'day' | 'week' | 'month';
    chartType: 'line' | 'bar' | 'pie';
}

export interface CardInfo {
    key: string;   // 例如 'revenueChart'、'heatmap'...
    title: string;
    subtitle?: string;
    type: 'chart' | 'heatmap' | 'table';
    data: any;
}

const BASE = '/api/ReportForm'; // 依你的後端實際路由調整

export async function fetchRevenueCardInfos(config: RevenueConfig): Promise<CardInfo[]> {
    /*const res = await fetch(`${BASE}/CardInfos/Revenue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`fetchRevenueCardInfos failed: ${res.status} ${text}`);
    }
    return await res.json();*/

    console.log('[Mock fetchRevenueCardInfos] called with:', config);

    // 模擬網路延遲 0.8 秒
    await new Promise(r => setTimeout(r, 800));

    // 假資料生成邏輯
    const baseDate = new Date(config.range.start);
    const points = Array.from({ length: 10 }, (_, i) => ({
        Date: new Date(baseDate.getTime() + i * 86400000).toISOString().split('T')[0],
        Revenue: Math.round(Math.random() * 30000 + 2000),
    }));

    return [
        {
            key: 'revenueChart',
            title: '收益趨勢圖',
            subtitle: `${config.groupBy} 統計`,
            type: 'chart',
            data: {
                label: '每日收益',
                data: points,
                chartType: config.chartType,
            },
        },
        {
            key: 'revenueHeatmap',
            title: '地區收益熱力圖',
            subtitle: '示意資料',
            type: 'heatmap',
            data: {
                points: [
                    { x: 30, y: 40, weight: 20000 },
                    { x: 50, y: 60, weight: 8000 },
                    { x: 70, y: 30, weight: 15000 },
                    { x: 40, y: 70, weight: 5000 },
                ],
            },
        },
    ];
}