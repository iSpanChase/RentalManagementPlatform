<template>
  <div class="col-4 py-3">
    <div class="card shadow-sm h-100">
      <!-- Header -->
      <div class="card-header d-flex justify-content-between align-items-center bg-light border-0">
        <div class="d-flex flex-column">
          <h5 class="mb-0 fw-semibold">{{ title }}</h5>
          <small v-if="subtitle" class="text-muted">{{ subtitle }}</small>
        </div>

        <div class="d-flex align-items-center gap-2">
          <slot name="header-extra"></slot>

          <button
            v-for="a in actions"
            :key="a.key"
            @click="emitAction(a.key)"
            class="btn btn-sm btn-outline-primary"
          >
            {{ a.label }}
          </button>

          <button
            v-if="collapsible"
            @click="collapsed = !collapsed"
            class="btn btn-sm btn-outline-secondary"
          >
            <font-awesome-icon :icon="collapsed ? ['fas', 'chevron-down'] : ['fas', 'chevron-up']" />
          </button>
        </div>
      </div>

      <!-- Loading -->
      <div v-if="loading" class="card-body text-center py-5 text-muted">
        <div class="spinner-border text-secondary" role="status"></div>
        <p class="mt-3">載入中...</p>
      </div>

      <!-- Body -->
      <div v-else v-show="!collapsed" class="card-body">
        <slot></slot>
      </div>

      <!-- Footer -->
      <div v-if="$slots.footer" class="card-footer bg-light border-0 text-muted small">
        <slot name="footer"></slot>
      </div>
    </div>
  </div>
  
</template>

<script setup>
import { ref } from 'vue';

defineProps({
  title: String,
  subtitle: String,
  loading: { type: Boolean, default: false },
  actions: { type: Array, default: () => [] },
  collapsible: { type: Boolean, default: true },
});

const collapsed = ref(false);
const emit = defineEmits(['update:config', 'remove', 'clicked']);
function emitAction(key) {
  emit('clicked', key);
}
</script>

<style scoped>
.card {
  border-radius: 0.75rem;
  transition: all 0.3s ease;
}

.card:hover {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.08);
}
</style>