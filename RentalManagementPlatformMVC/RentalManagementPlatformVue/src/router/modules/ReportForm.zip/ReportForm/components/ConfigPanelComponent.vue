<script setup lang="ts">
    import RevenueConfigPanel from './panels/RevenueConfigPanelComponent.vue';
    import OccupancyConfigPanel from './panels/OccupancyConfigPanelComponent.vue';
    import HeatmapConfigPanel from './panels/HeatmapConfigPanelComponent.vue';

    const props = defineProps<{
        kind: 'revenue' | 'occupancy' | 'heatmap';
        modelValue: any;
    }>();

    const emit = defineEmits(['update:modelValue']);

    function updateConfig(newVal: any) {
        emit('update:modelValue', newVal);
    }

    const panelMap = {
        revenue: RevenueConfigPanel,
        occupancy: OccupancyConfigPanel,
        heatmap: HeatmapConfigPanel
    };
</script>

<template>
    <div class="config-panel p-3 bg-light border rounded mb-3">
        <component
            :is="panelMap[kind]"
            :model-value="modelValue"
            @update:model-value="updateConfig"
        />
    </div>
</template>