<!-- src/modules/ReportForm/pages/IndexView.vue -->
<script setup lang="ts">
import { ref, watch } from 'vue';

import ConfigPanelComponent from '../components/ConfigPanelComponent.vue';
import BaseCardComponent from '../components/BaseCardComponent.vue';
import MapHeatmapCardComponent from '../components/cardInfos/MapHeatmapCardComponent.vue';
import ChartCardComponent from '../components/ChartCardComponent.vue';

import { fetchRevenueCardInfos, type RevenueConfig, type CardInfo } from '../api/reportForm';

// ---- 1) 初始設定（可改成今天/近30天等動態計算） ----
const revenueConfig = ref<RevenueConfig>({
  propertyIds: [],
  range: { start: '2025-10-01', end: '2025-10-22' },
  groupBy: 'day',
  chartType: 'line',
});

// ---- 2) 狀態 ----
const loading = ref(false);
const errorMsg = ref('');
const cardInfos = ref<CardInfo[]>([]);

// ---- 3) 請求函式 ----
async function loadCards() {
  loading.value = true;
  errorMsg.value = '';
  try {
    const data = await fetchRevenueCardInfos(revenueConfig.value);
    cardInfos.value = data;
  } catch (err: any) {
    errorMsg.value = err?.message ?? String(err);
  } finally {
    loading.value = false;
  }
}

// ---- 4) 監聽設定變更 → 重新載入（加 300ms 防抖） ----
let debounceTimer: any = null;
watch(revenueConfig, () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadCards, 300);
}, { deep: true });

// ---- 5) 初次載入 ----
loadCards();
</script>

<template>
  <div class="container">
    <!-- 設定面板（kind='revenue' 會載入 RevenueConfigPanelComponent） -->
    <ConfigPanelComponent v-model="revenueConfig" kind="revenue" class="mb-3" />

    <div v-if="errorMsg" class="alert alert-danger">{{ errorMsg }}</div>

    <div class="row">
      <!-- 把回來的 cardInfos 逐一渲染成卡片 -->
      <BaseCardComponent
        v-for="c in cardInfos"
        :key="c.key"
        class="col-4"
        :title="c.title"
        :subtitle="c.subtitle"
        :loading="loading"
      >
        <template v-if="c.type === 'heatmap'">
          <MapHeatmapCardComponent :points="c.data.points" />
        </template>

        <template v-else-if="c.type === 'chart'">
          <!-- 依你 ChartCardComponent 的 props 餵資料 -->
          <ChartCardComponent v-bind="c.data" />
        </template>

        <template v-else>
          <div class="p-3">
            （其他卡片型態：你可以做 TableCard、NumberCard 等）
          </div>
        </template>
      </BaseCardComponent>
    </div>
  </div>
</template>